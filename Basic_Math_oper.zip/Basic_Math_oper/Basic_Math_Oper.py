# Inderpreet Singh.
# program: Basic Math Operations:

# addition, Subtraction, Multiplication, Division, Exponential, Module.
a = 5
b = 6
# creating Variable add to perform addition between a and b
add: float = a + b
print('The Sum of a+b = ', add)

Sub: float = a - b
print('\nThe subtraction of a - b = ', Sub)

mult: float = a * b
print('\nThe Multiplication of a x b = ', mult)

div: float = a / b
print('\nThe division of a / b = ', div)

exp: float = a ** b
print('\nThe Sum of a^b = ', exp)
